import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  "appId": "com.shayos.focus",
  "appName": "ShayOS FOCUS",
  "webDir": "www",
  "server": {
    "url": "https://shaysport.com/he/focus/",
    "cleartext": false,
    "allowNavigation": [
      "shaysport.com",
      "*.shaysport.com"
    ]
  },
  "android": {
    "allowMixedContent": false,
    "captureInput": true,
    "webContentsDebuggingEnabled": false
  },
  "ios": {
    "contentInset": "automatic",
    "preferredContentMode": "mobile"
  }
};
export default config;
