import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const cfg=fs.readFileSync('capacitor.config.ts','utf8');
const required=['@capacitor/core','@capacitor/android','@capacitor/ios','@capacitor/app','@capacitor/network','@capacitor/share','@capacitor/browser','@capacitor/camera','@capacitor/filesystem','@capacitor/preferences','@capacitor/keyboard','@capacitor/splash-screen'];
const all={...(pkg.dependencies||{}),...(pkg.devDependencies||{})};
let ok=true;
for(const dep of required){if(!all[dep]){console.error(`Missing ${dep}`);ok=false;}}
if(!/[\"']?server[\"']?\s*:/.test(cfg)){console.error('Missing remote server configuration');ok=false;}
if(pkg.version!=='0.9.0'){console.error(`Unexpected version ${pkg.version}`);ok=false;}
if(!fs.existsSync('scripts/apply-native-config.mjs')){console.error('Missing native configuration script');ok=false;}
if(!fs.existsSync('native/templates/ios/PrivacyInfo.xcprivacy')){console.error('Missing iOS privacy manifest template');ok=false;}
if(!fs.existsSync('native/templates/android/ShayOSAudioCapturePlugin.java.tpl')){console.error('Missing Android audio capture adapter template');ok=false;}
const focus=JSON.parse(fs.readFileSync('config/profiles/focus.json','utf8'));
if(!focus.androidWidget||!Array.isArray(focus.androidWidget.actions)||focus.androidWidget.actions.length<3){console.error('Missing Android widget action contract');ok=false;}
for(const id of ['focus.home','focus.schedule','focus.create-item']){if(!focus.androidWidget.actions.some(a=>a&&a.id===id)){console.error(`Missing widget action ${id}`);ok=false;}}
if(!focus.androidIcon||!fs.existsSync(focus.androidIcon)){console.error('Missing canonical FOCUS Android icon');ok=false;}
if(!ok)process.exit(1);
console.log('ShayOS Platform Host source verification passed.');
