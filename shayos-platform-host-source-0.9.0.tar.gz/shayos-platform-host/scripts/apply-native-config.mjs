import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const profileName=process.argv[2]||process.env.SHAYOS_PROFILE||'focus';
const profilePath=path.join(root,'config','profiles',`${profileName}.json`);
if(!fs.existsSync(profilePath)) throw new Error(`Profile not found: ${profilePath}`);
const p=JSON.parse(fs.readFileSync(profilePath,'utf8'));
const host=new URL(p.siteUrl).hostname;

function patchFile(file, fn){ if(!fs.existsSync(file)) return false; const before=fs.readFileSync(file,'utf8'); const after=fn(before); if(after!==before) fs.writeFileSync(file,after); return true; }
function addBefore(text, marker, block){ if(text.includes(block.trim())) return text; const i=text.indexOf(marker); if(i<0) return text; return text.slice(0,i)+block+text.slice(i); }

const androidManifest=path.join(root,'android','app','src','main','AndroidManifest.xml');
if(fs.existsSync(androidManifest)){
  patchFile(androidManifest, text=>{
    const permissions=['android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE'];
    let out=text;
    for(const perm of permissions){ const line=`    <uses-permission android:name="${perm}" />\n`; if(!out.includes(`android:name="${perm}"`)) out=addBefore(out,'<application',line); }
    const filter=`\n            <intent-filter android:autoVerify="true">\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="https" android:host="${host}" />\n            </intent-filter>\n            <intent-filter>\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="${p.scheme||'shayos'}" />\n            </intent-filter>\n`;
    if(!out.includes(`android:host="${host}"`)) out=addBefore(out,'        </activity>',filter);
    if(p.androidWidget && Array.isArray(p.androidWidget.actions) && p.androidWidget.actions.length){
      const receiver=`
        <receiver android:name=".ShayOSQuickActionsWidget" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/shayos_quick_actions_widget_info" />
        </receiver>
`;
      if(!out.includes('android:name=".ShayOSQuickActionsWidget"')) out=addBefore(out,'    </application>',receiver);
    }
    if(p.androidIcon){
      out=out.replace(/android:icon="[^"]+"/,'android:icon="@drawable/shayos_app_icon"');
      if(/android:roundIcon="[^"]+"/.test(out)) out=out.replace(/android:roundIcon="[^"]+"/,'android:roundIcon="@drawable/shayos_app_icon"');
    }
    return out;
  });
  console.log('Configured AndroidManifest.xml');
}else console.log('Android project not present yet. Run npx cap add android first.');

if(p.androidIcon && fs.existsSync(androidManifest)){
  const iconSrc=path.resolve(root,String(p.androidIcon));
  const drawableDir=path.join(root,'android','app','src','main','res','drawable');
  if(fs.existsSync(iconSrc)){
    fs.mkdirSync(drawableDir,{recursive:true});
    fs.copyFileSync(iconSrc,path.join(drawableDir,'shayos_app_icon.png'));
    console.log('Installed canonical ShayOS app icon');
  }
}

const info=path.join(root,'ios','App','App','Info.plist');
if(fs.existsSync(info)){
  patchFile(info, text=>{
    const entries=`\n\t<key>NSCameraUsageDescription</key>\n\t<string>ShayOS uses the camera only when you choose to capture media.</string>\n\t<key>NSMicrophoneUsageDescription</key>\n\t<string>ShayOS uses the microphone only when you choose to record audio or video.</string>\n\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>ShayOS accesses your photo library only when you choose media to upload.</string>\n\t<key>NSPhotoLibraryAddUsageDescription</key>\n\t<string>ShayOS saves media only when you explicitly request it.</string>\n`;
    return text.includes('NSCameraUsageDescription')?text:addBefore(text,'</dict>',entries);
  });
  console.log('Configured iOS Info.plist permissions');
}else console.log('iOS project not present yet. Run npx cap add ios first.');

const entitlements=path.join(root,'ios','App','App','App.entitlements');
if(fs.existsSync(path.dirname(entitlements))){
  const data=`<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict><key>com.apple.developer.associated-domains</key><array><string>applinks:${host}</string></array></dict></plist>\n`;
  fs.writeFileSync(entitlements,data);
  console.log('Wrote iOS associated domains entitlements');
}
const privacySrc=path.join(root,'native','templates','ios','PrivacyInfo.xcprivacy');
const privacyDst=path.join(root,'ios','App','App','PrivacyInfo.xcprivacy');
if(fs.existsSync(path.dirname(privacyDst)) && fs.existsSync(privacySrc)){ fs.copyFileSync(privacySrc,privacyDst); console.log('Installed iOS PrivacyInfo.xcprivacy'); }

// Install the ShayOS platform-neutral audio capture adapter on Android.
const androidJavaDir=path.join(root,'android','app','src','main','java',...String(p.appId||'com.shayos.focus').split('.'));
const audioTpl=path.join(root,'native','templates','android','ShayOSAudioCapturePlugin.java.tpl');
const ttsTpl=path.join(root,'native','templates','android','ShayOSTextToSpeechPlugin.java.tpl');
if(fs.existsSync(androidJavaDir) && fs.existsSync(audioTpl) && fs.existsSync(ttsTpl)){
  fs.mkdirSync(androidJavaDir,{recursive:true});
  const audioDst=path.join(androidJavaDir,'ShayOSAudioCapturePlugin.java');
  const source=fs.readFileSync(audioTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(audioDst,source);
  const ttsDst=path.join(androidJavaDir,'ShayOSTextToSpeechPlugin.java');
  const ttsSource=fs.readFileSync(ttsTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(ttsDst,ttsSource);
  const mainActivity=path.join(androidJavaDir,'MainActivity.java');
  if(fs.existsSync(mainActivity)){
    const main=`package ${String(p.appId||'com.shayos.focus')};\n\nimport android.os.Bundle;\nimport android.webkit.WebSettings;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    super.onCreate(savedInstanceState);\n    registerPlugin(ShayOSAudioCapturePlugin.class);
    registerPlugin(ShayOSTextToSpeechPlugin.class);\n    if (getBridge() != null && getBridge().getWebView() != null) {\n      WebSettings settings = getBridge().getWebView().getSettings();\n      settings.setTextZoom(100);\n      settings.setMinimumFontSize(0);\n      settings.setMinimumLogicalFontSize(0);\n    }\n  }\n}\n`;
    fs.writeFileSync(mainActivity,main);
  }
  console.log('Installed ShayOSAudioCapture and ShayOSTextToSpeech Android adapters');
}


// Android home-screen widget. The widget contains only stable ShayOS Action IDs;
// navigation/business behavior remains owned by the web runtime and Platform Bridge.
if(fs.existsSync(androidJavaDir) && p.androidWidget && Array.isArray(p.androidWidget.actions) && p.androidWidget.actions.length){
  const actions=p.androidWidget.actions.slice(0,3);
  const resDir=path.join(root,'android','app','src','main','res');
  const layoutDir=path.join(resDir,'layout');
  const xmlDir=path.join(resDir,'xml');
  fs.mkdirSync(layoutDir,{recursive:true});
  fs.mkdirSync(xmlDir,{recursive:true});
  const ids=['shayos_widget_action_1','shayos_widget_action_2','shayos_widget_action_3'];
  const buttons=actions.map((a,i)=>`    <Button android:id="@+id/${ids[i]}" android:layout_width="0dp" android:layout_height="wrap_content" android:layout_weight="1" android:minHeight="48dp" android:text="${String(a.label||a.id).replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;')}" android:textAllCaps="false" />`).join('\n');
  fs.writeFileSync(path.join(layoutDir,'shayos_quick_actions_widget.xml'),`<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="vertical" android:padding="10dp" android:background="#FFFFFFFF">\n  <TextView android:id="@+id/shayos_widget_title" android:layout_width="match_parent" android:layout_height="wrap_content" android:text="${String(p.androidWidget.name||p.appName||'ShayOS').replaceAll('&','&amp;').replaceAll('"','&quot;')}" android:textStyle="bold" android:textSize="16sp" android:paddingBottom="8dp" />\n  <LinearLayout android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal">\n${buttons}\n  </LinearLayout>\n</LinearLayout>\n`);
  fs.writeFileSync(path.join(xmlDir,'shayos_quick_actions_widget_info.xml'),`<?xml version="1.0" encoding="utf-8"?>\n<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="250dp" android:minHeight="72dp" android:updatePeriodMillis="0" android:initialLayout="@layout/shayos_quick_actions_widget" android:resizeMode="horizontal|vertical" android:widgetCategory="home_screen" />\n`);
  const javaActions=actions.map((a,i)=>`    bind(context, views, appWidgetId, R.id.${ids[i]}, ${i+1}, "${String(a.id||'').replaceAll('\\','\\\\').replaceAll('"','\\"')}");`).join('\n');
  const widgetJava=`package ${String(p.appId||'com.shayos.focus')};\n\nimport android.app.PendingIntent;\nimport android.appwidget.AppWidgetManager;\nimport android.appwidget.AppWidgetProvider;\nimport android.content.Context;\nimport android.content.Intent;\nimport android.net.Uri;\nimport android.widget.RemoteViews;\n\npublic class ShayOSQuickActionsWidget extends AppWidgetProvider {\n  @Override\n  public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {\n    for (int appWidgetId : appWidgetIds) {\n      RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.shayos_quick_actions_widget);\n${javaActions}\n      manager.updateAppWidget(appWidgetId, views);\n    }\n  }\n\n  private static void bind(Context context, RemoteViews views, int widgetId, int viewId, int requestOffset, String actionId) {\n    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("${String(p.scheme||'shayos')}://action/" + actionId));\n    intent.setPackage(context.getPackageName());\n    int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;\n    PendingIntent pending = PendingIntent.getActivity(context, widgetId * 10 + requestOffset, intent, flags);\n    views.setOnClickPendingIntent(viewId, pending);\n  }\n}\n`;
  fs.writeFileSync(path.join(androidJavaDir,'ShayOSQuickActionsWidget.java'),widgetJava);
  console.log('Installed ShayOS Android quick-actions widget using stable Action IDs');
}
