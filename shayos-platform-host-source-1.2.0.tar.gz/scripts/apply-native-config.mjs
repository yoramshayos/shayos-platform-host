import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const profileName=process.argv[2]||process.env.SHAYOS_PROFILE||'focus';
const profilePath=path.join(root,'config','profiles',`${profileName}.json`);
if(!fs.existsSync(profilePath)) throw new Error(`Profile not found: ${profilePath}`);
const p=JSON.parse(fs.readFileSync(profilePath,'utf8'));
const host=new URL(p.siteUrl).hostname;

function patchFile(file, fn){ if(!fs.existsSync(file)) return false; const before=fs.readFileSync(file,'utf8'); const after=fn(before); if(after!==before) fs.writeFileSync(file,after); return true; }
function addBefore(text, marker, block){ if(text.includes(block.trim())) return text; const i=text.indexOf(marker); if(i<0) return text; return text.slice(0,i)+block+text.slice(i); }

const androidManifest=path.join(root,'android','app','src','main','AndroidManifest.xml');
if(fs.existsSync(androidManifest)){
  patchFile(androidManifest, text=>{
    const permissions=['android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE'];
    let out=text;
    for(const perm of permissions){ const line=`    <uses-permission android:name="${perm}" />\n`; if(!out.includes(`android:name="${perm}"`)) out=addBefore(out,'<application',line); }
    const ttsQuery=`\n    <queries>\n        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>\n    </queries>\n`;
    if(!out.includes('android.intent.action.TTS_SERVICE')) out=addBefore(out,'<application',ttsQuery);
    const filter=`\n            <intent-filter android:autoVerify="true">\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="https" android:host="${host}" />\n            </intent-filter>\n            <intent-filter>\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="${p.scheme||'shayos'}" />\n            </intent-filter>\n`;
    if(!out.includes(`android:host="${host}"`)) out=addBefore(out,'        </activity>',filter);
    if(p.androidIcon){
      out=out.replace(/android:icon="[^"]+"/,'android:icon="@drawable/shayos_app_icon"');
      if(/android:roundIcon="[^"]+"/.test(out)) out=out.replace(/android:roundIcon="[^"]+"/,'android:roundIcon="@drawable/shayos_app_icon"');
    }
    return out;
  });
  console.log('Configured AndroidManifest.xml');
}else console.log('Android project not present yet. Run npx cap add android first.');

if(p.androidIcon && fs.existsSync(androidManifest)){
  const iconSrc=path.resolve(root,String(p.androidIcon));
  const drawableDir=path.join(root,'android','app','src','main','res','drawable');
  if(fs.existsSync(iconSrc)){
    fs.mkdirSync(drawableDir,{recursive:true});
    fs.copyFileSync(iconSrc,path.join(drawableDir,'shayos_app_icon.png'));
    console.log('Installed canonical ShayOS app icon');
  }
}

const info=path.join(root,'ios','App','App','Info.plist');
if(fs.existsSync(info)){
  patchFile(info, text=>{
    const entries=`\n\t<key>NSCameraUsageDescription</key>\n\t<string>ShayOS uses the camera only when you choose to capture media.</string>\n\t<key>NSMicrophoneUsageDescription</key>\n\t<string>ShayOS uses the microphone only when you choose to record audio or video.</string>\n\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>ShayOS accesses your photo library only when you choose media to upload.</string>\n\t<key>NSPhotoLibraryAddUsageDescription</key>\n\t<string>ShayOS saves media only when you explicitly request it.</string>\n`;
    return text.includes('NSCameraUsageDescription')?text:addBefore(text,'</dict>',entries);
  });
  console.log('Configured iOS Info.plist permissions');
}else console.log('iOS project not present yet. Run npx cap add ios first.');

const entitlements=path.join(root,'ios','App','App','App.entitlements');
if(fs.existsSync(path.dirname(entitlements))){
  const data=`<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict><key>com.apple.developer.associated-domains</key><array><string>applinks:${host}</string></array></dict></plist>\n`;
  fs.writeFileSync(entitlements,data);
  console.log('Wrote iOS associated domains entitlements');
}
const privacySrc=path.join(root,'native','templates','ios','PrivacyInfo.xcprivacy');
const privacyDst=path.join(root,'ios','App','App','PrivacyInfo.xcprivacy');
if(fs.existsSync(path.dirname(privacyDst)) && fs.existsSync(privacySrc)){ fs.copyFileSync(privacySrc,privacyDst); console.log('Installed iOS PrivacyInfo.xcprivacy'); }

// Install the ShayOS platform-neutral audio capture adapter on Android.
const androidJavaDir=path.join(root,'android','app','src','main','java',...String(p.appId||'com.shayos.focus').split('.'));
const audioTpl=path.join(root,'native','templates','android','ShayOSAudioCapturePlugin.java.tpl');
const ttsTpl=path.join(root,'native','templates','android','ShayOSTextToSpeechPlugin.java.tpl');
const sttTpl=path.join(root,'native','templates','android','ShayOSSpeechToTextPlugin.java.tpl');
if(fs.existsSync(androidJavaDir) && fs.existsSync(audioTpl) && fs.existsSync(ttsTpl) && fs.existsSync(sttTpl)){
  fs.mkdirSync(androidJavaDir,{recursive:true});
  const audioDst=path.join(androidJavaDir,'ShayOSAudioCapturePlugin.java');
  const source=fs.readFileSync(audioTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(audioDst,source);
  const ttsDst=path.join(androidJavaDir,'ShayOSTextToSpeechPlugin.java');
  const ttsSource=fs.readFileSync(ttsTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(ttsDst,ttsSource);
  const sttDst=path.join(androidJavaDir,'ShayOSSpeechToTextPlugin.java');
  const sttSource=fs.readFileSync(sttTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(sttDst,sttSource);
  const mainActivity=path.join(androidJavaDir,'MainActivity.java');
  if(fs.existsSync(mainActivity)){
    const main=`package ${String(p.appId||'com.shayos.focus')};\n\nimport android.content.Intent;\nimport android.net.Uri;\nimport android.os.Bundle;\nimport android.webkit.WebSettings;\nimport android.webkit.WebView;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  private static final String DEFAULT_URL = \"https://shaysport.com/he/focus?page=focus\";\n  private String pendingTarget;\n  private int pendingAttempts;\n\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(ShayOSAudioCapturePlugin.class);\n    registerPlugin(ShayOSSpeechToTextPlugin.class);\n    registerPlugin(ShayOSTextToSpeechPlugin.class);\n    registerPlugin(ShayOSIncomingSharePlugin.class);\n\n    Intent original = getIntent();\n    ShayOSIncomingSharePlugin.captureIntent(original, this);\n    pendingTarget = extractTarget(original);\n    sanitizeConsumedIntent(original);\n\n    super.onCreate(savedInstanceState);\n\n    if (getBridge() != null && getBridge().getWebView() != null) {\n      WebSettings settings = getBridge().getWebView().getSettings();\n      settings.setTextZoom(100);\n      settings.setMinimumFontSize(0);\n      settings.setMinimumLogicalFontSize(0);\n    }\n    schedulePendingNavigation();\n  }\n\n  @Override\n  protected void onNewIntent(Intent intent) {\n    ShayOSIncomingSharePlugin.captureIntent(intent, this);\n    String target = extractTarget(intent);\n    sanitizeConsumedIntent(intent);\n    super.onNewIntent(intent);\n    setIntent(intent);\n    if (target != null) {\n      pendingTarget = target;\n      pendingAttempts = 0;\n      schedulePendingNavigation();\n    }\n  }\n\n  private String extractTarget(Intent intent) {\n    if (intent == null) return null;\n    String action = intent.getAction();\n    if (Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action)) {\n      return \"https://shaysport.com/he/focus?page=focus&wizard=create-item&source=android-share\";\n    }\n    Uri data = intent.getData();\n    if (data != null && \"https\".equalsIgnoreCase(data.getScheme()) && isInternalHost(data.getHost())) {\n      return data.toString();\n    }\n    if (action != null && action.startsWith(\"com.shayos.focus.WIDGET.\")) {\n      return data != null ? data.toString() : DEFAULT_URL;\n    }\n    return null;\n  }\n\n  private boolean isInternalHost(String host) {\n    if (host == null) return false;\n    String h = host.toLowerCase();\n    return h.equals(\"shaysport.com\") || h.endsWith(\".shaysport.com\") ||\n           h.equals(\"shaymichaeli.co.il\") || h.endsWith(\".shaymichaeli.co.il\");\n  }\n\n  private void sanitizeConsumedIntent(Intent intent) {\n    if (intent == null) return;\n    String action = intent.getAction();\n    if ((action != null && action.startsWith(\"com.shayos.focus.WIDGET.\")) ||\n        Intent.ACTION_SEND.equals(action) || Intent.ACTION_SEND_MULTIPLE.equals(action) ||\n        (intent.getData() != null && isInternalHost(intent.getData().getHost()))) {\n      intent.setData(null);\n      intent.setAction(Intent.ACTION_MAIN);\n    }\n  }\n\n  private void schedulePendingNavigation() {\n    if (pendingTarget == null || getBridge() == null || getBridge().getWebView() == null) return;\n    final WebView webView = getBridge().getWebView();\n    webView.postDelayed(new Runnable() {\n      @Override public void run() {\n        if (pendingTarget == null) return;\n        String current = webView.getUrl();\n        boolean bridgeReady = current != null && !current.isEmpty() && !\"about:blank\".equals(current);\n        if (!bridgeReady && pendingAttempts++ < 40) {\n          webView.postDelayed(this, 150);\n          return;\n        }\n        String target = pendingTarget;\n        pendingTarget = null;\n        pendingAttempts = 0;\n        if (target != null && !target.equals(current)) webView.loadUrl(target);\n      }\n    }, 150);\n  }\n}\n`;
    fs.writeFileSync(mainActivity,main);
  }
  console.log('Installed ShayOSAudioCapture, ShayOSSpeechToText and ShayOSTextToSpeech Android adapters');
}




// Android incoming Share Sheet. Home-screen widgets are intentionally not generated.
if(fs.existsSync(androidJavaDir)){
  const appId=String(p.appId||'com.shayos.focus');
  if(p.androidShare && p.androidShare.enabled){
    const shareJava=`package ${appId};\n\nimport android.app.Activity; import android.content.*; import android.database.Cursor; import android.net.Uri; import android.provider.OpenableColumns; import android.util.Base64; import com.getcapacitor.*; import com.getcapacitor.annotation.CapacitorPlugin; import java.io.*; import java.util.*;\n@CapacitorPlugin(name="ShayOSIncomingShare") public class ShayOSIncomingSharePlugin extends Plugin {\n private static JSObject pending; private static final int MAX=20*1024*1024;\n public static synchronized void captureIntent(Intent in, Activity a){ if(in==null)return; String act=in.getAction(); if(!Intent.ACTION_SEND.equals(act)&&!Intent.ACTION_SEND_MULTIPLE.equals(act))return; JSObject root=new JSObject(); root.put("action",act); root.put("type",in.getType()==null?"":in.getType()); root.put("text",in.getStringExtra(Intent.EXTRA_TEXT)); root.put("subject",in.getStringExtra(Intent.EXTRA_SUBJECT)); JSArray files=new JSArray(); ArrayList<Uri> uris=new ArrayList<>(); if(Intent.ACTION_SEND_MULTIPLE.equals(act)){ ArrayList<Uri> x=in.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(x!=null)uris.addAll(x); } else { Uri u=in.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null)uris.add(u); } for(Uri u:uris){ try{ JSObject f=new JSObject(); f.put("uri",u.toString()); f.put("name",name(a,u)); f.put("mime",a.getContentResolver().getType(u)); try(InputStream is=a.getContentResolver().openInputStream(u); ByteArrayOutputStream os=new ByteArrayOutputStream()){ byte[] b=new byte[8192]; int n,total=0; while((n=is.read(b))>0){ total+=n; if(total>MAX)throw new IOException("shared file exceeds 20 MB native handoff limit"); os.write(b,0,n);} f.put("dataBase64",Base64.encodeToString(os.toByteArray(),Base64.NO_WRAP)); } files.put(f); }catch(Exception e){ JSObject f=new JSObject(); f.put("uri",u.toString()); f.put("error",e.getMessage()); files.put(f); }} root.put("files",files); pending=root; }\n private static String name(Activity a,Uri u){ String n=null; try(Cursor c=a.getContentResolver().query(u,null,null,null,null)){ if(c!=null&&c.moveToFirst()){ int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0)n=c.getString(i); }}catch(Exception ignored){} return n==null?"shared-file":n; }\n @PluginMethod public synchronized void getPendingShare(PluginCall call){ JSObject r=new JSObject(); r.put("share",pending); pending=null; call.resolve(r); }\n @PluginMethod public synchronized void peekPendingShare(PluginCall call){ JSObject r=new JSObject(); r.put("share",pending); call.resolve(r); } }\n`;
    fs.writeFileSync(path.join(androidJavaDir,'ShayOSIncomingSharePlugin.java'),shareJava);
    patchFile(androidManifest,text=>{
      if(text.includes('android.intent.action.SEND')) return text;
      const filters=`\n            <intent-filter><action android:name="android.intent.action.SEND"/><category android:name="android.intent.category.DEFAULT"/><data android:mimeType="*/*"/></intent-filter>\n            <intent-filter><action android:name="android.intent.action.SEND_MULTIPLE"/><category android:name="android.intent.category.DEFAULT"/><data android:mimeType="*/*"/></intent-filter>\n`;
      return addBefore(text,'        </activity>',filters);
    });
  }
}
