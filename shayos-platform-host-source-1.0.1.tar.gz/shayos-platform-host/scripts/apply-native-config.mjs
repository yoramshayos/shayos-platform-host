import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const profileName=process.argv[2]||process.env.SHAYOS_PROFILE||'focus';
const profilePath=path.join(root,'config','profiles',`${profileName}.json`);
if(!fs.existsSync(profilePath)) throw new Error(`Profile not found: ${profilePath}`);
const p=JSON.parse(fs.readFileSync(profilePath,'utf8'));
const host=new URL(p.siteUrl).hostname;

function patchFile(file, fn){ if(!fs.existsSync(file)) return false; const before=fs.readFileSync(file,'utf8'); const after=fn(before); if(after!==before) fs.writeFileSync(file,after); return true; }
function addBefore(text, marker, block){ if(text.includes(block.trim())) return text; const i=text.indexOf(marker); if(i<0) return text; return text.slice(0,i)+block+text.slice(i); }

const androidManifest=path.join(root,'android','app','src','main','AndroidManifest.xml');
if(fs.existsSync(androidManifest)){
  patchFile(androidManifest, text=>{
    const permissions=['android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE'];
    let out=text;
    for(const perm of permissions){ const line=`    <uses-permission android:name="${perm}" />\n`; if(!out.includes(`android:name="${perm}"`)) out=addBefore(out,'<application',line); }
    const ttsQuery=`\n    <queries>\n        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>\n    </queries>\n`;
    if(!out.includes('android.intent.action.TTS_SERVICE')) out=addBefore(out,'<application',ttsQuery);
    const filter=`\n            <intent-filter android:autoVerify="true">\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="https" android:host="${host}" />\n            </intent-filter>\n            <intent-filter>\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="${p.scheme||'shayos'}" />\n            </intent-filter>\n`;
    if(!out.includes(`android:host="${host}"`)) out=addBefore(out,'        </activity>',filter);
    if(Array.isArray(p.androidWidgets) && p.androidWidgets.length){
      for(const w of p.androidWidgets){
        const suffix=String(w.id||'widget').replace(/[^A-Za-z0-9]/g,'_');
        const className=`ShayOSWidget_${suffix}`;
        const infoName=`shayos_widget_${String(w.id||'widget').replace(/[^a-z0-9_]/gi,'_').toLowerCase()}_info`;
        const receiver=`
        <receiver android:name=".${className}" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/${infoName}" />
        </receiver>
`;
        if(!out.includes(`android:name=".${className}"`)) out=addBefore(out,'    </application>',receiver);
      }
    }
    if(p.androidIcon){
      out=out.replace(/android:icon="[^"]+"/,'android:icon="@drawable/shayos_app_icon"');
      if(/android:roundIcon="[^"]+"/.test(out)) out=out.replace(/android:roundIcon="[^"]+"/,'android:roundIcon="@drawable/shayos_app_icon"');
    }
    return out;
  });
  console.log('Configured AndroidManifest.xml');
}else console.log('Android project not present yet. Run npx cap add android first.');

if(p.androidIcon && fs.existsSync(androidManifest)){
  const iconSrc=path.resolve(root,String(p.androidIcon));
  const drawableDir=path.join(root,'android','app','src','main','res','drawable');
  if(fs.existsSync(iconSrc)){
    fs.mkdirSync(drawableDir,{recursive:true});
    fs.copyFileSync(iconSrc,path.join(drawableDir,'shayos_app_icon.png'));
    console.log('Installed canonical ShayOS app icon');
  }
}

const info=path.join(root,'ios','App','App','Info.plist');
if(fs.existsSync(info)){
  patchFile(info, text=>{
    const entries=`\n\t<key>NSCameraUsageDescription</key>\n\t<string>ShayOS uses the camera only when you choose to capture media.</string>\n\t<key>NSMicrophoneUsageDescription</key>\n\t<string>ShayOS uses the microphone only when you choose to record audio or video.</string>\n\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>ShayOS accesses your photo library only when you choose media to upload.</string>\n\t<key>NSPhotoLibraryAddUsageDescription</key>\n\t<string>ShayOS saves media only when you explicitly request it.</string>\n`;
    return text.includes('NSCameraUsageDescription')?text:addBefore(text,'</dict>',entries);
  });
  console.log('Configured iOS Info.plist permissions');
}else console.log('iOS project not present yet. Run npx cap add ios first.');

const entitlements=path.join(root,'ios','App','App','App.entitlements');
if(fs.existsSync(path.dirname(entitlements))){
  const data=`<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict><key>com.apple.developer.associated-domains</key><array><string>applinks:${host}</string></array></dict></plist>\n`;
  fs.writeFileSync(entitlements,data);
  console.log('Wrote iOS associated domains entitlements');
}
const privacySrc=path.join(root,'native','templates','ios','PrivacyInfo.xcprivacy');
const privacyDst=path.join(root,'ios','App','App','PrivacyInfo.xcprivacy');
if(fs.existsSync(path.dirname(privacyDst)) && fs.existsSync(privacySrc)){ fs.copyFileSync(privacySrc,privacyDst); console.log('Installed iOS PrivacyInfo.xcprivacy'); }

// Install the ShayOS platform-neutral audio capture adapter on Android.
const androidJavaDir=path.join(root,'android','app','src','main','java',...String(p.appId||'com.shayos.focus').split('.'));
const audioTpl=path.join(root,'native','templates','android','ShayOSAudioCapturePlugin.java.tpl');
const ttsTpl=path.join(root,'native','templates','android','ShayOSTextToSpeechPlugin.java.tpl');
if(fs.existsSync(androidJavaDir) && fs.existsSync(audioTpl) && fs.existsSync(ttsTpl)){
  fs.mkdirSync(androidJavaDir,{recursive:true});
  const audioDst=path.join(androidJavaDir,'ShayOSAudioCapturePlugin.java');
  const source=fs.readFileSync(audioTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(audioDst,source);
  const ttsDst=path.join(androidJavaDir,'ShayOSTextToSpeechPlugin.java');
  const ttsSource=fs.readFileSync(ttsTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(ttsDst,ttsSource);
  const mainActivity=path.join(androidJavaDir,'MainActivity.java');
  if(fs.existsSync(mainActivity)){
    const main=`package ${String(p.appId||'com.shayos.focus')};\n\nimport android.os.Bundle;\nimport android.webkit.WebSettings;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(ShayOSAudioCapturePlugin.class);
    registerPlugin(ShayOSTextToSpeechPlugin.class);\n    super.onCreate(savedInstanceState);\n    if (getBridge() != null && getBridge().getWebView() != null) {\n      WebSettings settings = getBridge().getWebView().getSettings();\n      settings.setTextZoom(100);\n      settings.setMinimumFontSize(0);\n      settings.setMinimumLogicalFontSize(0);\n    }\n  }\n}\n`;
    fs.writeFileSync(mainActivity,main);
  }
  console.log('Installed ShayOSAudioCapture and ShayOSTextToSpeech Android adapters');
}


// Android home-screen widgets. FOCUS exposes exactly two independent widgets.
// Each provider dispatches one stable ShayOS Action ID. Business/navigation behavior remains web-owned.
if(fs.existsSync(androidJavaDir) && Array.isArray(p.androidWidgets) && p.androidWidgets.length){
  const widgets=p.androidWidgets.slice(0,2);
  const resDir=path.join(root,'android','app','src','main','res');
  const layoutDir=path.join(resDir,'layout');
  const xmlDir=path.join(resDir,'xml');
  fs.mkdirSync(layoutDir,{recursive:true});
  fs.mkdirSync(xmlDir,{recursive:true});
  for(const w of widgets){
    const key=String(w.id||'widget').replace(/[^a-z0-9_]/gi,'_').toLowerCase();
    const suffix=String(w.id||'widget').replace(/[^A-Za-z0-9]/g,'_');
    const className=`ShayOSWidget_${suffix}`;
    const layoutName=`shayos_widget_${key}`;
    const infoName=`shayos_widget_${key}_info`;
    const action=(w.action||{});
    const label=String(action.label||w.name||action.id||'FOCUS').replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');
    fs.writeFileSync(path.join(layoutDir,`${layoutName}.xml`),`<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:id="@+id/shayos_widget_root" android:layout_width="match_parent" android:layout_height="wrap_content" android:orientation="horizontal" android:gravity="center_vertical" android:padding="10dp" android:background="#FFFFFFFF">\n  <ImageView android:layout_width="36dp" android:layout_height="36dp" android:src="@drawable/shayos_app_icon" android:contentDescription="FOCUS" android:scaleType="fitCenter" android:layout_marginEnd="10dp" />\n  <TextView android:id="@+id/shayos_widget_label" android:layout_width="0dp" android:layout_height="48dp" android:layout_weight="1" android:gravity="center" android:text="${label}" android:textStyle="bold" android:textSize="16sp" android:textColor="#174B7A" />\n</LinearLayout>\n`);
    fs.writeFileSync(path.join(xmlDir,`${infoName}.xml`),`<?xml version="1.0" encoding="utf-8"?>\n<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="180dp" android:minHeight="56dp" android:updatePeriodMillis="0" android:initialLayout="@layout/${layoutName}" android:resizeMode="horizontal" android:widgetCategory="home_screen" android:description="@string/app_name" />\n`);
    const actionId=String(action.id||'').replaceAll('\\','\\\\').replaceAll('"','\\"');
    const widgetJava=`package ${String(p.appId||'com.shayos.focus')};\n\nimport android.app.PendingIntent;\nimport android.appwidget.AppWidgetManager;\nimport android.appwidget.AppWidgetProvider;\nimport android.content.Context;\nimport android.content.Intent;\nimport android.net.Uri;\nimport android.widget.RemoteViews;\n\npublic class ${className} extends AppWidgetProvider {\n  @Override\n  public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {\n    for (int appWidgetId : appWidgetIds) {\n      RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.${layoutName});\n      Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("${String(p.scheme||'shayos')}://action/${actionId}"));\n      intent.setPackage(context.getPackageName());\n      int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;\n      PendingIntent pending = PendingIntent.getActivity(context, appWidgetId, intent, flags);\n      views.setOnClickPendingIntent(R.id.shayos_widget_root, pending);\n      views.setOnClickPendingIntent(R.id.shayos_widget_label, pending);\n      manager.updateAppWidget(appWidgetId, views);\n    }\n  }\n}\n`;
    fs.writeFileSync(path.join(androidJavaDir,`${className}.java`),widgetJava);
  }
  console.log('Installed exactly two FOCUS Android action widgets: create activity and start now');
}
