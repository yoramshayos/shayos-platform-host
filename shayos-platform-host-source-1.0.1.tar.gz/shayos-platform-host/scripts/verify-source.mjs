import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const cfg=fs.readFileSync('capacitor.config.ts','utf8');
const required=['@capacitor/core','@capacitor/android','@capacitor/ios','@capacitor/app','@capacitor/network','@capacitor/share','@capacitor/browser','@capacitor/camera','@capacitor/filesystem','@capacitor/preferences','@capacitor/keyboard','@capacitor/splash-screen'];
const all={...(pkg.dependencies||{}),...(pkg.devDependencies||{})};
let ok=true;
for(const dep of required){if(!all[dep]){console.error(`Missing ${dep}`);ok=false;}}
if(!/[\"']?server[\"']?\s*:/.test(cfg)){console.error('Missing remote server configuration');ok=false;}
if(pkg.version!=='1.0.1'){console.error(`Unexpected version ${pkg.version}`);ok=false;}
if(!fs.existsSync('scripts/apply-native-config.mjs')){console.error('Missing native configuration script');ok=false;}

if(/captureInput\s*:\s*true/.test(cfg)){console.error('Android captureInput must stay false to preserve standard IME composition and caret behavior');ok=false;}
const nativeCfg=fs.readFileSync('scripts/apply-native-config.mjs','utf8');
const audioReg=nativeCfg.indexOf('registerPlugin(ShayOSAudioCapturePlugin.class)');
const ttsReg=nativeCfg.indexOf('registerPlugin(ShayOSTextToSpeechPlugin.class)');
const superCreate=nativeCfg.indexOf('super.onCreate(savedInstanceState)');
if(audioReg<0||ttsReg<0||superCreate<0||audioReg>superCreate||ttsReg>superCreate){console.error('Native ShayOS plugins must be registered before BridgeActivity creates the bridge');ok=false;}
if(!nativeCfg.includes('android.intent.action.TTS_SERVICE')){console.error('Missing Android TTS service visibility declaration');ok=false;}
if(!fs.existsSync('native/templates/ios/PrivacyInfo.xcprivacy')){console.error('Missing iOS privacy manifest template');ok=false;}
if(!fs.existsSync('native/templates/android/ShayOSAudioCapturePlugin.java.tpl')){console.error('Missing Android audio capture adapter template');ok=false;}
const focus=JSON.parse(fs.readFileSync('config/profiles/focus.json','utf8'));
if(!Array.isArray(focus.androidWidgets)||focus.androidWidgets.length!==2){console.error('FOCUS must expose exactly two Android widgets');ok=false;}
const widgetActions=(focus.androidWidgets||[]).map(w=>w&&w.action&&w.action.id).filter(Boolean);
for(const id of ['focus.create-item','focus.start-now']){if(!widgetActions.includes(id)){console.error(`Missing widget action ${id}`);ok=false;}}
if(widgetActions.some(id=>['focus.home','focus.schedule','focus.what-connects'].includes(id))){console.error('Legacy multi-action widget actions must not be exposed');ok=false;}
if(!focus.androidIcon||!fs.existsSync(focus.androidIcon)){console.error('Missing canonical FOCUS Android icon');ok=false;}
if(!ok)process.exit(1);
console.log('ShayOS Platform Host source verification passed.');
