import fs from 'node:fs';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const cfg=fs.readFileSync('capacitor.config.ts','utf8');
const required=['@capacitor/core','@capacitor/android','@capacitor/ios','@capacitor/app','@capacitor/network','@capacitor/share','@capacitor/browser','@capacitor/camera','@capacitor/filesystem','@capacitor/preferences','@capacitor/keyboard','@capacitor/splash-screen'];
const all={...(pkg.dependencies||{}),...(pkg.devDependencies||{})};
let ok=true;
for(const dep of required){if(!all[dep]){console.error(`Missing ${dep}`);ok=false;}}
if(!/[\"']?server[\"']?\s*:/.test(cfg)){console.error('Missing remote server configuration');ok=false;}
if(pkg.version!=='1.1.1'){console.error(`Unexpected version ${pkg.version}`);ok=false;}
if(!fs.existsSync('scripts/apply-native-config.mjs')){console.error('Missing native configuration script');ok=false;}

if(/captureInput\s*:\s*true/.test(cfg)){console.error('Android captureInput must stay false to preserve standard IME composition and caret behavior');ok=false;}
const nativeCfg=fs.readFileSync('scripts/apply-native-config.mjs','utf8');
const audioReg=nativeCfg.indexOf('registerPlugin(ShayOSAudioCapturePlugin.class)');
const sttReg=nativeCfg.indexOf('registerPlugin(ShayOSSpeechToTextPlugin.class)');
const ttsReg=nativeCfg.indexOf('registerPlugin(ShayOSTextToSpeechPlugin.class)');
const superCreate=nativeCfg.indexOf('super.onCreate(savedInstanceState)');
if(audioReg<0||sttReg<0||ttsReg<0||superCreate<0||audioReg>superCreate||sttReg>superCreate||ttsReg>superCreate){console.error('Native ShayOS plugins must be registered before BridgeActivity creates the bridge');ok=false;}
if(!nativeCfg.includes('android.intent.action.TTS_SERVICE')){console.error('Missing Android TTS service visibility declaration');ok=false;}
if(!fs.existsSync('native/templates/ios/PrivacyInfo.xcprivacy')){console.error('Missing iOS privacy manifest template');ok=false;}
if(!fs.existsSync('native/templates/android/ShayOSAudioCapturePlugin.java.tpl')){console.error('Missing Android audio capture adapter template');ok=false;}
if(!fs.existsSync('native/templates/android/ShayOSSpeechToTextPlugin.java.tpl')){console.error('Missing Android streaming speech-to-text adapter template');ok=false;}
const focus=JSON.parse(fs.readFileSync('config/profiles/focus.json','utf8'));
if(!focus.androidWidget||!Array.isArray(focus.androidWidget.actions)||focus.androidWidget.actions.length!==3){console.error('FOCUS must expose one Android widget with exactly three actions');ok=false;}
const widgetActions=((focus.androidWidget||{}).actions||[]).map(a=>a&&a.id).filter(Boolean);
for(const id of ['focus.home','focus.create-item','focus.start-now']){if(!widgetActions.includes(id)){console.error(`Missing widget action ${id}`);ok=false;}}
if(!Array.isArray(focus.internalNavigationHosts)||!focus.internalNavigationHosts.includes('shaymichaeli.co.il')){console.error('Leoro must be an internal WebView host');ok=false;}
if(!focus.androidShare||!focus.androidShare.enabled){console.error('Android incoming share must be enabled');ok=false;}
if(!focus.androidIcon||!fs.existsSync(focus.androidIcon)){console.error('Missing canonical FOCUS Android icon');ok=false;}

if(!nativeCfg.includes('android:previewLayout')){console.error('Widget picker previewLayout missing');ok=false;}
if(!nativeCfg.includes('new Intent(c,MainActivity.class)')){console.error('Widget must route explicitly to MainActivity');ok=false;}
if(!nativeCfg.includes('ShayOSIncomingSharePlugin')){console.error('Incoming share plugin missing');ok=false;}
if(!nativeCfg.includes('android.intent.action.SEND')){console.error('Android Share Sheet intent filter missing');ok=false;}
if(sttReg<0){console.error('ShayOSSpeechToText plugin registration missing');ok=false;}
if(!ok)process.exit(1);
console.log('ShayOS Platform Host source verification passed.');
