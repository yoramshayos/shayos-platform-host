/* ShayOS Platform Host 1.1.1 */
(function(){
'use strict';
var KEY='shayos.host.state.v1';
var initial={siteUrl:'',lastUrl:'',lastSiteId:'',lastAction:'',updatedAt:0};
function load(){try{return Object.assign({},initial,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch(e){return Object.assign({},initial);}}
function save(patch){var next=Object.assign(load(),patch||{},{updatedAt:Date.now()});try{localStorage.setItem(KEY,JSON.stringify(next));}catch(e){}return next;}
var INTERNAL_HOSTS=['shaysport.com','www.shaysport.com','shaymichaeli.co.il','www.shaymichaeli.co.il'];
function internalUrl(url){try{return INTERNAL_HOSTS.indexOf(new URL(url,location.href).hostname.toLowerCase())>=0;}catch(e){return false;}}
function bind(){
 document.addEventListener('shayos:platform:ready',function(e){save({lastUrl:location.href,lastSiteId:(window.ShayOSPlatformRuntime||{}).siteId||''});});
 document.addEventListener('shayos:platform:action',function(e){save({lastAction:e&&e.detail&&e.detail.id||'',lastUrl:location.href});});
 document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden')save({lastUrl:location.href});});
 window.addEventListener('pagehide',function(){save({lastUrl:location.href});});
 document.addEventListener('click',function(e){var a=e.target&&e.target.closest?e.target.closest('a[href]'):null;if(!a)return;var href=a.href||'';if(!href)return;if(/^https?:/i.test(href)&&!internalUrl(href)){var bridge=window.ShayOSPlatformBridge;if(bridge&&bridge.isNative&&bridge.isNative()&&bridge.openExternal){e.preventDefault();bridge.openExternal(href);}}},true);
}
window.ShayOSHost={version:'1.1.1',loadState:load,saveState:save};
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind,{once:true});else bind();
})();
