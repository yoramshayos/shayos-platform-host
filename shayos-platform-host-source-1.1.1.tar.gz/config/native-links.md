# Native link configuration

The host uses the canonical `shayos` scheme. Public HTTPS links remain the preferred install-aware fallback.

## Android

The Android adapter should claim the selected ShayOS site's HTTPS App Links and the `shayos` custom scheme. The website must expose the matching `/.well-known/assetlinks.json` for the final package ID and signing certificate.

## iOS

The iOS adapter should register the `shayos` URL scheme and the selected site's Associated Domains entry. The website must expose the matching `/.well-known/apple-app-site-association` for the final Team ID and bundle ID.

## xOS and Windows

Future adapters must translate their platform-specific activation/link mechanism into the same incoming URL/action contract exposed to `ShayOSPlatformBridge`. Product plugins must not contain xOS- or Windows-specific branches.
