# Native links

The canonical ShayOS scheme is `shayos://`.

The Bridge Core also exposes hooks for the two HTTPS association files:

- `/.well-known/assetlinks.json`
- `/.well-known/apple-app-site-association`

Production values must be supplied by site-specific filters after the Android signing certificate fingerprint and Apple Team ID/bundle ID are known.

Action identifiers stay semantic, for example `focus.video-editor`, and must not depend on a platform-specific URL.
