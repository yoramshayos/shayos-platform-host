# ShayOS Platform Host build

The host is platform-neutral. Android and iOS are the first build adapters. xOS and Windows remain future adapters behind the same ShayOS Platform Bridge contract.

## First native build

1. Install Node dependencies with `npm install`.
2. Select a profile with `npm run profile -- focus`.
3. Add native projects with `npm run native:init`.
4. Apply ShayOS native configuration with `npm run native:configure -- focus`.
5. Sync with `npm run cap:sync`.
6. Open Android Studio with `npm run cap:open:android` or Xcode with `npm run cap:open:ios`.

The remote ShayOS site remains the source of UI and business logic. Native rebuilds are needed only when the host, native permissions, platform adapters, signing, icons/splash, or store metadata change.
