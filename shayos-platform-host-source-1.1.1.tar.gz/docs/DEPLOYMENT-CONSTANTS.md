# Deployment constants

Bridge Core 1.2.0 can publish the association files needed by Android App Links and Apple Universal Links without product-specific code.

Add these values in deployment configuration when signing identities are known:

```php
define('SHAYOS_ANDROID_APP_ID', 'com.shayos.focus');
define('SHAYOS_ANDROID_SHA256_CERT_FINGERPRINTS', ['AA:BB:CC:...']);
define('SHAYOS_APPLE_TEAM_ID', 'YOURTEAMID');
define('SHAYOS_IOS_APP_ID', 'com.shayos.focus');
```

The Android fingerprint must match the certificate used for the installed build. The Apple Team ID must match the signing team used for the iOS application.
