# Android APK build

The first Android target is the ShayOS FOCUS profile (`com.shayos.focus`).

## Cloud build

The repository includes `.github/workflows/android-debug-apk.yml`.
Trigger `Build Android Debug APK` manually from GitHub Actions, or push to `main`.
The workflow uploads `shayos-focus-debug-apk`, containing `app-debug.apk`.

## Install on a phone

Download `app-debug.apk` to the Android phone and open it. Android may ask once for permission to install apps from the browser or file manager used to open the APK. This debug build is intended for direct device testing, not Play Store distribution.

## Release build

A Play Store AAB and signed release APK require a release signing key. Do not commit signing passwords or keystore secrets to the repository.
