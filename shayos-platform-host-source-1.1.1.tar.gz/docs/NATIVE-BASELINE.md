# Native baseline 0.4.0

## Android

The native configuration step adds manifest declarations for camera, microphone, internet and network state, plus HTTPS App Links and the canonical `shayos` scheme. Camera and microphone must still be requested at runtime only when the corresponding flow is used.

## iOS

The native configuration step adds camera, microphone and photo library usage descriptions, Associated Domains for Universal Links and `PrivacyInfo.xcprivacy` entries needed by Preferences and Filesystem.

## Bridge APIs

Bridge Core 1.2.0 adds `preferenceGet`, `preferenceSet`, `preferenceRemove`, `capturePhoto`, `pickImages`, `writeFile`, `readFile`, `keyboardHide` and `hostCapabilities`.

Video and audio capture remain routed through the existing FOCUS media flows until a common cross-platform capture contract is finalized. Product code must not call Android or iOS APIs directly.
