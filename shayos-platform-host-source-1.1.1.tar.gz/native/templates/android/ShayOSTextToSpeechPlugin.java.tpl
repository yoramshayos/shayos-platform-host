package __APP_PACKAGE__;

import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.Locale;
import java.util.UUID;
import android.speech.tts.UtteranceProgressListener;

@CapacitorPlugin(name = "ShayOSTextToSpeech")
public class ShayOSTextToSpeechPlugin extends Plugin {
    private TextToSpeech tts;
    private volatile boolean ready = false;
    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    public void load() {
        tts = new TextToSpeech(getContext(), status -> ready = status == TextToSpeech.SUCCESS);
    }

    @PluginMethod
    public void speak(PluginCall call) {
        final String text = call.getString("text", "").trim();
        final String lang = call.getString("lang", "he-IL");
        final Double rateValue = call.getDouble("rate", 0.96);
        if (text.isEmpty()) { call.reject("speech_text_required"); return; }
        speakWhenReady(call, text, lang, rateValue == null ? 0.96f : rateValue.floatValue(), 0);
    }

    private void speakWhenReady(PluginCall call, String text, String lang, float rate, int attempt) {
        if (tts == null) { call.reject("tts_unavailable"); return; }
        if (!ready) {
            if (attempt >= 20) { call.reject("tts_not_ready"); return; }
            main.postDelayed(() -> speakWhenReady(call, text, lang, rate, attempt + 1), 100);
            return;
        }
        try {
            Locale locale = Locale.forLanguageTag(lang == null || lang.isEmpty() ? "he-IL" : lang);
            tts.setLanguage(locale);
            tts.setSpeechRate(Math.max(0.2f, Math.min(rate, 2.0f)));
            final String utteranceId = "shayos-tts-" + UUID.randomUUID();
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {}
                @Override public void onDone(String id) {
                    if (!utteranceId.equals(id)) return;
                    JSObject ret = new JSObject(); ret.put("spoken", true); call.resolve(ret);
                }
                @Override public void onError(String id) {
                    if (utteranceId.equals(id)) call.reject("tts_speak_failed");
                }
            });
            int result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
            if (result == TextToSpeech.ERROR) call.reject("tts_speak_failed");
        } catch (Exception e) { call.reject("tts_speak_failed", e); }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        try { if (tts != null) tts.stop(); JSObject ret = new JSObject(); ret.put("stopped", true); call.resolve(ret); }
        catch (Exception e) { call.reject("tts_stop_failed", e); }
    }

    @Override
    protected void handleOnDestroy() {
        if (tts != null) { try { tts.stop(); tts.shutdown(); } catch (Exception ignored) {} tts = null; }
        ready = false;
        super.handleOnDestroy();
    }
}
