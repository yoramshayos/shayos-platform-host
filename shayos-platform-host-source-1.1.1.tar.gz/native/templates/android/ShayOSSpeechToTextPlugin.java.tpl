package __APP_PACKAGE__;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.util.ArrayList;

@CapacitorPlugin(
    name = "ShayOSSpeechToText",
    permissions = { @Permission(alias = "microphone", strings = { Manifest.permission.RECORD_AUDIO }) }
)
public class ShayOSSpeechToTextPlugin extends Plugin implements RecognitionListener {
    private SpeechRecognizer recognizer;
    private PluginCall pendingStartCall;
    private boolean active = false;

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "microphonePermsCallback");
            return;
        }
        startInternal(call);
    }

    @PermissionCallback
    private void microphonePermsCallback(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) startInternal(call);
        else call.reject("microphone_permission_denied");
    }

    private void startInternal(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
                call.reject("speech_recognition_unavailable");
                return;
            }
            destroyRecognizer();
            try {
                recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                recognizer.setRecognitionListener(this);
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                String lang = call.getString("lang", "he-IL");
                if (lang != null && !lang.isEmpty()) intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, call.getBoolean("partialResults", true));
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                pendingStartCall = call;
                active = true;
                recognizer.startListening(intent);
            } catch (Exception e) {
                active = false;
                pendingStartCall = null;
                destroyRecognizer();
                call.reject("speech_recognition_start_failed", e);
            }
        });
    }

    @PluginMethod
    public void stop(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            try {
                if (recognizer != null && active) recognizer.stopListening();
                JSObject ret = new JSObject(); ret.put("stopping", true); call.resolve(ret);
            } catch (Exception e) { call.reject("speech_recognition_stop_failed", e); }
        });
    }

    @PluginMethod
    public void cancel(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            try { if (recognizer != null) recognizer.cancel(); } catch (Exception ignored) {}
            active = false;
            destroyRecognizer();
            JSObject ret = new JSObject(); ret.put("cancelled", true); call.resolve(ret);
        });
    }

    private String firstResult(Bundle results) {
        if (results == null) return "";
        ArrayList<String> values = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return values != null && !values.isEmpty() && values.get(0) != null ? values.get(0).trim() : "";
    }

    private void emitText(String event, Bundle results) {
        String text = firstResult(results);
        if (text.isEmpty()) return;
        JSObject data = new JSObject(); data.put("text", text); notifyListeners(event, data, true);
    }

    private void emitState(String state) {
        JSObject data = new JSObject(); data.put("state", state); notifyListeners("state", data, true);
    }

    @Override public void onReadyForSpeech(Bundle params) {
        if (pendingStartCall != null) {
            JSObject ret = new JSObject(); ret.put("started", true); pendingStartCall.resolve(ret); pendingStartCall = null;
        }
        emitState("listening");
    }
    @Override public void onBeginningOfSpeech() { emitState("speech"); }
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() { emitState("processing"); }
    @Override public void onPartialResults(Bundle partialResults) { emitText("partialResult", partialResults); }
    @Override public void onResults(Bundle results) {
        emitText("finalResult", results); active = false; destroyRecognizer();
    }
    @Override public void onError(int error) {
        if (pendingStartCall != null) { pendingStartCall.reject("speech_recognition_error_" + error); pendingStartCall = null; }
        JSObject data = new JSObject(); data.put("code", error); notifyListeners("error", data, true);
        active = false; destroyRecognizer();
    }
    @Override public void onEvent(int eventType, Bundle params) {}

    private void destroyRecognizer() {
        if (recognizer != null) {
            try { recognizer.destroy(); } catch (Exception ignored) {}
            recognizer = null;
        }
    }

    @Override protected void handleOnDestroy() {
        active = false; pendingStartCall = null; destroyRecognizer(); super.handleOnDestroy();
    }
}
