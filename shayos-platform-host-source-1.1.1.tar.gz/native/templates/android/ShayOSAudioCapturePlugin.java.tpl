package __APP_PACKAGE__;

import android.Manifest;
import android.media.MediaRecorder;
import android.util.Base64;

import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;

@CapacitorPlugin(
    name = "ShayOSAudioCapture",
    permissions = { @Permission(alias = "microphone", strings = { Manifest.permission.RECORD_AUDIO }) }
)
public class ShayOSAudioCapturePlugin extends Plugin {
    private MediaRecorder recorder;
    private File outputFile;

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "microphonePermsCallback");
            return;
        }
        startInternal(call);
    }

    @PermissionCallback
    private void microphonePermsCallback(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) startInternal(call);
        else call.reject("microphone_permission_denied");
    }

    private void startInternal(PluginCall call) {
        if (recorder != null) { call.reject("audio_capture_already_running"); return; }
        try {
            outputFile = File.createTempFile("shayos-audio-", ".m4a", getContext().getCacheDir());
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(outputFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            JSObject ret = new JSObject(); ret.put("started", true); call.resolve(ret);
        } catch (Exception e) {
            releaseRecorder();
            if (outputFile != null) outputFile.delete();
            outputFile = null;
            call.reject("audio_capture_start_failed", e);
        }
    }

    @PluginMethod
    public void stop(PluginCall call) {
        if (recorder == null || outputFile == null) { call.reject("audio_capture_not_running"); return; }
        try {
            recorder.stop();
            releaseRecorder();
            byte[] bytes = readAll(outputFile);
            JSObject ret = new JSObject();
            ret.put("base64", Base64.encodeToString(bytes, Base64.NO_WRAP));
            ret.put("mimeType", "audio/mp4");
            ret.put("filename", outputFile.getName());
            ret.put("size", bytes.length);
            outputFile.delete(); outputFile = null;
            call.resolve(ret);
        } catch (Exception e) {
            releaseRecorder();
            if (outputFile != null) outputFile.delete();
            outputFile = null;
            call.reject("audio_capture_stop_failed", e);
        }
    }

    @Override
    protected void handleOnDestroy() {
        releaseRecorder();
        if (outputFile != null) outputFile.delete();
        outputFile = null;
        super.handleOnDestroy();
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
    }

    private byte[] readAll(File file) throws Exception {
        try (FileInputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[16384]; int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }
}
