import fs from 'node:fs';
import path from 'node:path';

const root=process.cwd();
const profileName=process.argv[2]||process.env.SHAYOS_PROFILE||'focus';
const profilePath=path.join(root,'config','profiles',`${profileName}.json`);
if(!fs.existsSync(profilePath)) throw new Error(`Profile not found: ${profilePath}`);
const p=JSON.parse(fs.readFileSync(profilePath,'utf8'));
const host=new URL(p.siteUrl).hostname;

function patchFile(file, fn){ if(!fs.existsSync(file)) return false; const before=fs.readFileSync(file,'utf8'); const after=fn(before); if(after!==before) fs.writeFileSync(file,after); return true; }
function addBefore(text, marker, block){ if(text.includes(block.trim())) return text; const i=text.indexOf(marker); if(i<0) return text; return text.slice(0,i)+block+text.slice(i); }

const androidManifest=path.join(root,'android','app','src','main','AndroidManifest.xml');
if(fs.existsSync(androidManifest)){
  patchFile(androidManifest, text=>{
    const permissions=['android.permission.CAMERA','android.permission.RECORD_AUDIO','android.permission.INTERNET','android.permission.ACCESS_NETWORK_STATE'];
    let out=text;
    for(const perm of permissions){ const line=`    <uses-permission android:name="${perm}" />\n`; if(!out.includes(`android:name="${perm}"`)) out=addBefore(out,'<application',line); }
    const ttsQuery=`\n    <queries>\n        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>\n    </queries>\n`;
    if(!out.includes('android.intent.action.TTS_SERVICE')) out=addBefore(out,'<application',ttsQuery);
    const filter=`\n            <intent-filter android:autoVerify="true">\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="https" android:host="${host}" />\n            </intent-filter>\n            <intent-filter>\n                <action android:name="android.intent.action.VIEW" />\n                <category android:name="android.intent.category.DEFAULT" />\n                <category android:name="android.intent.category.BROWSABLE" />\n                <data android:scheme="${p.scheme||'shayos'}" />\n            </intent-filter>\n`;
    if(!out.includes(`android:host="${host}"`)) out=addBefore(out,'        </activity>',filter);
    if(false && Array.isArray(p.androidWidgets) && p.androidWidgets.length){
      for(const w of p.androidWidgets){
        const suffix=String(w.id||'widget').replace(/[^A-Za-z0-9]/g,'_');
        const className=`ShayOSWidget_${suffix}`;
        const infoName=`shayos_widget_${String(w.id||'widget').replace(/[^a-z0-9_]/gi,'_').toLowerCase()}_info`;
        const receiver=`
        <receiver android:name=".${className}" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE" />
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/${infoName}" />
        </receiver>
`;
        if(!out.includes(`android:name=".${className}"`)) out=addBefore(out,'    </application>',receiver);
      }
    }
    if(p.androidIcon){
      out=out.replace(/android:icon="[^"]+"/,'android:icon="@drawable/shayos_app_icon"');
      if(/android:roundIcon="[^"]+"/.test(out)) out=out.replace(/android:roundIcon="[^"]+"/,'android:roundIcon="@drawable/shayos_app_icon"');
    }
    return out;
  });
  console.log('Configured AndroidManifest.xml');
}else console.log('Android project not present yet. Run npx cap add android first.');

if(p.androidIcon && fs.existsSync(androidManifest)){
  const iconSrc=path.resolve(root,String(p.androidIcon));
  const drawableDir=path.join(root,'android','app','src','main','res','drawable');
  if(fs.existsSync(iconSrc)){
    fs.mkdirSync(drawableDir,{recursive:true});
    fs.copyFileSync(iconSrc,path.join(drawableDir,'shayos_app_icon.png'));
    console.log('Installed canonical ShayOS app icon');
  }
}

const info=path.join(root,'ios','App','App','Info.plist');
if(fs.existsSync(info)){
  patchFile(info, text=>{
    const entries=`\n\t<key>NSCameraUsageDescription</key>\n\t<string>ShayOS uses the camera only when you choose to capture media.</string>\n\t<key>NSMicrophoneUsageDescription</key>\n\t<string>ShayOS uses the microphone only when you choose to record audio or video.</string>\n\t<key>NSPhotoLibraryUsageDescription</key>\n\t<string>ShayOS accesses your photo library only when you choose media to upload.</string>\n\t<key>NSPhotoLibraryAddUsageDescription</key>\n\t<string>ShayOS saves media only when you explicitly request it.</string>\n`;
    return text.includes('NSCameraUsageDescription')?text:addBefore(text,'</dict>',entries);
  });
  console.log('Configured iOS Info.plist permissions');
}else console.log('iOS project not present yet. Run npx cap add ios first.');

const entitlements=path.join(root,'ios','App','App','App.entitlements');
if(fs.existsSync(path.dirname(entitlements))){
  const data=`<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict><key>com.apple.developer.associated-domains</key><array><string>applinks:${host}</string></array></dict></plist>\n`;
  fs.writeFileSync(entitlements,data);
  console.log('Wrote iOS associated domains entitlements');
}
const privacySrc=path.join(root,'native','templates','ios','PrivacyInfo.xcprivacy');
const privacyDst=path.join(root,'ios','App','App','PrivacyInfo.xcprivacy');
if(fs.existsSync(path.dirname(privacyDst)) && fs.existsSync(privacySrc)){ fs.copyFileSync(privacySrc,privacyDst); console.log('Installed iOS PrivacyInfo.xcprivacy'); }

// Install the ShayOS platform-neutral audio capture adapter on Android.
const androidJavaDir=path.join(root,'android','app','src','main','java',...String(p.appId||'com.shayos.focus').split('.'));
const audioTpl=path.join(root,'native','templates','android','ShayOSAudioCapturePlugin.java.tpl');
const ttsTpl=path.join(root,'native','templates','android','ShayOSTextToSpeechPlugin.java.tpl');
const sttTpl=path.join(root,'native','templates','android','ShayOSSpeechToTextPlugin.java.tpl');
if(fs.existsSync(androidJavaDir) && fs.existsSync(audioTpl) && fs.existsSync(ttsTpl) && fs.existsSync(sttTpl)){
  fs.mkdirSync(androidJavaDir,{recursive:true});
  const audioDst=path.join(androidJavaDir,'ShayOSAudioCapturePlugin.java');
  const source=fs.readFileSync(audioTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(audioDst,source);
  const ttsDst=path.join(androidJavaDir,'ShayOSTextToSpeechPlugin.java');
  const ttsSource=fs.readFileSync(ttsTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(ttsDst,ttsSource);
  const sttDst=path.join(androidJavaDir,'ShayOSSpeechToTextPlugin.java');
  const sttSource=fs.readFileSync(sttTpl,'utf8').replaceAll('__APP_PACKAGE__',String(p.appId||'com.shayos.focus'));
  fs.writeFileSync(sttDst,sttSource);
  const mainActivity=path.join(androidJavaDir,'MainActivity.java');
  if(fs.existsSync(mainActivity)){
    const main=`package ${String(p.appId||'com.shayos.focus')};\n\nimport android.content.Intent;\nimport android.os.Bundle;\nimport android.webkit.WebSettings;\nimport com.getcapacitor.BridgeActivity;\n\npublic class MainActivity extends BridgeActivity {\n  @Override\n  public void onCreate(Bundle savedInstanceState) {\n    registerPlugin(ShayOSAudioCapturePlugin.class);
    registerPlugin(ShayOSSpeechToTextPlugin.class);
    registerPlugin(ShayOSTextToSpeechPlugin.class);\n    registerPlugin(ShayOSIncomingSharePlugin.class);\n    super.onCreate(savedInstanceState);\n    ShayOSIncomingSharePlugin.captureIntent(getIntent(), this);\n    handleLaunchIntent(getIntent());\n    if (getBridge() != null && getBridge().getWebView() != null) {\n      WebSettings settings = getBridge().getWebView().getSettings();\n      settings.setTextZoom(100);\n      settings.setMinimumFontSize(0);\n      settings.setMinimumLogicalFontSize(0);\n    }\n  }\n  @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); ShayOSIncomingSharePlugin.captureIntent(intent, this); handleLaunchIntent(intent); }\n  private void handleLaunchIntent(Intent intent) { if (intent == null || getBridge() == null || getBridge().getWebView() == null) return; String action=intent.getAction(); String target=null; if (Intent.ACTION_SEND.equals(action)||Intent.ACTION_SEND_MULTIPLE.equals(action)) target=\"https://shaysport.com/he/focus?page=focus&wizard=create-item&source=android-share\"; else if(intent.getData()!=null && \"https\".equalsIgnoreCase(intent.getData().getScheme())) target=intent.getData().toString(); if(target!=null) getBridge().getWebView().loadUrl(target); }\n}\n`;
    fs.writeFileSync(mainActivity,main);
  }
  console.log('Installed ShayOSAudioCapture, ShayOSSpeechToText and ShayOSTextToSpeech Android adapters');
}




// FOCUS Android single 3-action widget and Android incoming Share Sheet.
if(fs.existsSync(androidJavaDir)){
  const appId=String(p.appId||'com.shayos.focus');
  const resDir=path.join(root,'android','app','src','main','res');
  const layoutDir=path.join(resDir,'layout'), xmlDir=path.join(resDir,'xml'), drawableDir=path.join(resDir,'drawable'), valuesDir=path.join(resDir,'values');
  for(const d of [layoutDir,xmlDir,drawableDir,valuesDir]) fs.mkdirSync(d,{recursive:true});
  const widget=p.androidWidget;
  if(widget && Array.isArray(widget.actions) && widget.actions.length===3){
    fs.writeFileSync(path.join(layoutDir,'shayos_widget_focus_actions.xml'),`<?xml version="1.0" encoding="utf-8"?>\n<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android" android:layout_width="match_parent" android:layout_height="72dp" android:orientation="horizontal" android:gravity="center" android:padding="6dp" android:background="#00FFFFFF">\n  <ImageButton android:id="@+id/action_home" android:layout_width="58dp" android:layout_height="58dp" android:src="@drawable/shayos_app_icon" android:background="@drawable/shayos_widget_button" android:contentDescription="FOCUS" android:scaleType="fitCenter" android:padding="7dp" />\n  <TextView android:id="@+id/action_create" android:layout_width="58dp" android:layout_height="58dp" android:layout_marginStart="8dp" android:gravity="center" android:text="+" android:textSize="38sp" android:textStyle="bold" android:textColor="#FFFFFF" android:shadowColor="#99000000" android:shadowDx="2" android:shadowDy="3" android:shadowRadius="2" android:background="@drawable/shayos_widget_button" android:contentDescription="יצירת פעילות חדשה" />\n  <TextView android:id="@+id/action_now" android:layout_width="58dp" android:layout_height="58dp" android:layout_marginStart="8dp" android:gravity="center" android:text="(" android:textSize="36sp" android:textStyle="bold" android:textColor="#FFFFFF" android:shadowColor="#99000000" android:shadowDx="2" android:shadowDy="3" android:shadowRadius="2" android:background="@drawable/shayos_widget_button" android:contentDescription="פתיחת פעילות מיידית" />\n</LinearLayout>\n`);
    fs.writeFileSync(path.join(drawableDir,'shayos_widget_button.xml'),`<?xml version="1.0" encoding="utf-8"?>\n<layer-list xmlns:android="http://schemas.android.com/apk/res/android"><item android:left="3dp" android:top="4dp"><shape><corners android:radius="16dp"/><solid android:color="#55000000"/></shape></item><item android:right="3dp" android:bottom="4dp"><shape><corners android:radius="16dp"/><gradient android:startColor="#4E91C8" android:endColor="#174B7A" android:angle="270"/><stroke android:width="1dp" android:color="#80FFFFFF"/></shape></item></layer-list>\n`);
    fs.writeFileSync(path.join(xmlDir,'shayos_widget_focus_actions_info.xml'),`<?xml version="1.0" encoding="utf-8"?>\n<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android" android:minWidth="190dp" android:minHeight="72dp" android:updatePeriodMillis="0" android:initialLayout="@layout/shayos_widget_focus_actions" android:previewLayout="@layout/shayos_widget_focus_actions" android:resizeMode="none" android:widgetCategory="home_screen" android:description="@string/shayos_widget_focus_actions_description" />\n`);
    fs.writeFileSync(path.join(valuesDir,'shayos_widget_descriptions.xml'),`<?xml version="1.0" encoding="utf-8"?><resources><string name="shayos_widget_focus_actions_description">FOCUS - פעולות מהירות</string></resources>\n`);
    const actions=widget.actions;
    const java=`package ${appId};\n\nimport android.app.PendingIntent; import android.appwidget.AppWidgetManager; import android.appwidget.AppWidgetProvider; import android.content.Context; import android.content.Intent; import android.net.Uri; import android.widget.RemoteViews;\npublic class ShayOSWidget_focus_actions extends AppWidgetProvider {\n private PendingIntent pi(Context c,int widgetId,int request,String url){ Intent i=new Intent(c,MainActivity.class); i.setAction("com.shayos.focus.WIDGET."+request); i.setData(Uri.parse(url)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); return PendingIntent.getActivity(c,widgetId*10+request,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}\n @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){ for(int id:ids){ RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.shayos_widget_focus_actions); v.setOnClickPendingIntent(R.id.action_home,pi(c,id,1,"${actions[0].url}")); v.setOnClickPendingIntent(R.id.action_create,pi(c,id,2,"${actions[1].url}")); v.setOnClickPendingIntent(R.id.action_now,pi(c,id,3,"${actions[2].url}")); m.updateAppWidget(id,v); }} }\n`;
    fs.writeFileSync(path.join(androidJavaDir,'ShayOSWidget_focus_actions.java'),java);
    patchFile(androidManifest,text=>{
      let out=text;
      const receiver=`\n        <receiver android:name=".ShayOSWidget_focus_actions" android:exported="true"><intent-filter><action android:name="android.appwidget.action.APPWIDGET_UPDATE" /></intent-filter><meta-data android:name="android.appwidget.provider" android:resource="@xml/shayos_widget_focus_actions_info" /></receiver>\n`;
      if(!out.includes('.ShayOSWidget_focus_actions')) out=addBefore(out,'    </application>',receiver);
      return out;
    });
  }
  if(p.androidShare && p.androidShare.enabled){
    const shareJava=`package ${appId};\n\nimport android.app.Activity; import android.content.*; import android.database.Cursor; import android.net.Uri; import android.provider.OpenableColumns; import android.util.Base64; import com.getcapacitor.*; import com.getcapacitor.annotation.CapacitorPlugin; import java.io.*; import java.util.*;\n@CapacitorPlugin(name="ShayOSIncomingShare") public class ShayOSIncomingSharePlugin extends Plugin {\n private static JSObject pending; private static final int MAX=20*1024*1024;\n public static synchronized void captureIntent(Intent in, Activity a){ if(in==null)return; String act=in.getAction(); if(!Intent.ACTION_SEND.equals(act)&&!Intent.ACTION_SEND_MULTIPLE.equals(act))return; JSObject root=new JSObject(); root.put("action",act); root.put("type",in.getType()==null?"":in.getType()); root.put("text",in.getStringExtra(Intent.EXTRA_TEXT)); root.put("subject",in.getStringExtra(Intent.EXTRA_SUBJECT)); JSArray files=new JSArray(); ArrayList<Uri> uris=new ArrayList<>(); if(Intent.ACTION_SEND_MULTIPLE.equals(act)){ ArrayList<Uri> x=in.getParcelableArrayListExtra(Intent.EXTRA_STREAM); if(x!=null)uris.addAll(x); } else { Uri u=in.getParcelableExtra(Intent.EXTRA_STREAM); if(u!=null)uris.add(u); } for(Uri u:uris){ try{ JSObject f=new JSObject(); f.put("uri",u.toString()); f.put("name",name(a,u)); f.put("mime",a.getContentResolver().getType(u)); try(InputStream is=a.getContentResolver().openInputStream(u); ByteArrayOutputStream os=new ByteArrayOutputStream()){ byte[] b=new byte[8192]; int n,total=0; while((n=is.read(b))>0){ total+=n; if(total>MAX)throw new IOException("shared file exceeds 20 MB native handoff limit"); os.write(b,0,n);} f.put("dataBase64",Base64.encodeToString(os.toByteArray(),Base64.NO_WRAP)); } files.put(f); }catch(Exception e){ JSObject f=new JSObject(); f.put("uri",u.toString()); f.put("error",e.getMessage()); files.put(f); }} root.put("files",files); pending=root; }\n private static String name(Activity a,Uri u){ String n=null; try(Cursor c=a.getContentResolver().query(u,null,null,null,null)){ if(c!=null&&c.moveToFirst()){ int i=c.getColumnIndex(OpenableColumns.DISPLAY_NAME); if(i>=0)n=c.getString(i); }}catch(Exception ignored){} return n==null?"shared-file":n; }\n @PluginMethod public synchronized void getPendingShare(PluginCall call){ JSObject r=new JSObject(); r.put("share",pending); pending=null; call.resolve(r); }\n @PluginMethod public synchronized void peekPendingShare(PluginCall call){ JSObject r=new JSObject(); r.put("share",pending); call.resolve(r); } }\n`;
    fs.writeFileSync(path.join(androidJavaDir,'ShayOSIncomingSharePlugin.java'),shareJava);
    patchFile(androidManifest,text=>{
      if(text.includes('android.intent.action.SEND')) return text;
      const filters=`\n            <intent-filter><action android:name="android.intent.action.SEND"/><category android:name="android.intent.category.DEFAULT"/><data android:mimeType="*/*"/></intent-filter>\n            <intent-filter><action android:name="android.intent.action.SEND_MULTIPLE"/><category android:name="android.intent.category.DEFAULT"/><data android:mimeType="*/*"/></intent-filter>\n`;
      return addBefore(text,'        </activity>',filters);
    });
  }
}
