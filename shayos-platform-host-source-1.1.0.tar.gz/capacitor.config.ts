import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  "appId": "com.shayos.focus",
  "appName": "FOCUS by ShayOS",
  "webDir": "www",
  "server": {
    "url": "https://shaysport.com/he/focus/",
    "cleartext": false,
    "allowNavigation": [
      "shaysport.com",
      "www.shaysport.com",
      "shaymichaeli.co.il",
      "www.shaymichaeli.co.il"
    ]
  },
  "android": {
    "allowMixedContent": false,
    "captureInput": false,
    "webContentsDebuggingEnabled": false
  },
  "ios": {
    "contentInset": "automatic",
    "preferredContentMode": "mobile"
  }
};
export default config;
